import math
from collections.abc import Callable

import numpy as np


def bracket_minimum(func: Callable, a: float, b: float) -> tuple[float, float, float]:
    """Use the algorithm on lecture 7 slide to find a a 3 point bracket for a function.
    Note that depending on the function and initial guess for a and b, this function is not guaranteed to find a bracket for only 1 minimum!
    There is no way to know this without evaluating the function at many points. This is why we have to restart often.
    """
    phi = (1 + math.sqrt(5)) / 2  # Golden ratio
    fa, fb = func(a), func(b)
    switched_ab = False
    if fb > fa:  # Step 1: ensure f(b) < f(a)
        fa, fb = fb, fa
        a, b = b, a
        switched_ab = True
    c = b + (b - a) * phi  # Step 2
    while True:
        if (fc := func(c)) > fb:  # Step 3a
            return (c, b, a) if switched_ab else (a, b, c)

        # Step 3b: fit a polynomial. for this we can use LU Decomposition of a Vandermonde matrix
        # OR (since the minimum of the polynomial can be analytically defined using a,b,c and fa,fb,fc), we use the formula for this on slide 11 (Brent's method)
        d = (
            b
            - 0.5 * (b - a) ** 2 * (fb - fc)
            - (b - c) ** 2 * (fb - fa) / ((b - a) * (fb - fc) - (b - c) * (fb - fa))
        )
        fd = func(d)
        if b < d < c:
            if fd < fc:  # Step 4
                return (b, d, c)
            if fd > fb:
                return (a, b, d)
            d = c + (c - b) * phi
        else:  # Step 5
            d = c + (c - b) * phi
        a, b, c = b, c, d
        fa, fb = fb, fc


def golden_section_search(
    func: Callable,
    a: float,
    b: float,
    c: float,
    rel_target_acc: float = (np.finfo(float).eps) ** 0.5,
    max_num_iterations: int = 50,
) -> tuple[float, int]:
    """Iteratively tighten a 3 point bracket surrounding a minimum. This function assumes there is only 1 minimum inside the bracket.
    Use the algorithm defined in lecture 7 slide 10.
    For a minimization algorithm we can only hope to get as close to the minimum as the square root of the
    RELATIVE machine error epsilon times the x-value of the minimum, hence rel_target_acc: float = (np.finfo(float).eps) ** 0.5

    """
    phi = (1 + math.sqrt(5)) / 2  # Golden ratio
    w = 2 - phi
    c_min_b, b_min_a = abs(c - b), abs(b - a)
    other_edge = c if c_min_b > b_min_a else a  # Step 1
    iteration = 1
    while iteration < max_num_iterations:
        d = b + (other_edge - b) * w
        fb, fd = func(b), func(d)
        if (
            abs(c - a) < rel_target_acc * b
        ):  # Step 2. rel_target_acc * b to make it absolute target accuracy!
            if fd < fb:
                return d, iteration
            return b, iteration
        if fd < fb:  # Step 3
            if b < d < c:
                a, b = b, d
                c_min_b, b_min_a = abs(c - b), abs(
                    b - a
                )  # I need more lines for the various cases,
                other_edge = (
                    c if c_min_b > b_min_a else a
                )  # but it is more efficient because I do not always have to recompute both intervals and check which value should become other_edge
            else:
                c, b = b, d
                c_min_b, b_min_a = abs(c - b), abs(b - a)
                other_edge = c if c_min_b > b_min_a else a
        else:  # Step 4
            if b < d < c:
                c = d
                c_min_b = abs(
                    c - b
                )  # Step 5 optimization: only recompute tightened interval. Here larger interval is b_min_a
                other_edge = a
            else:
                a = d
                b_min_a = abs(b - a)
                other_edge = c
        iteration += 1
    return None, iteration
