from collections.abc import Callable
from functools import partial
from typing import Union

import numpy as np
from Q1_nx_Nx_and_A import N_func, f_profile, get_normalization_constant, n_func

# The function that we are going to fit and thus want to use as our model function is N, which we import


def partial_f_a(x, a, b, c):
    return f_profile(x, a, b, c) * np.log(x / b)


def partial_f_b(x, a, b, c):
    return f_profile(x, a, b, c) * (-(a - 3) / b + (c / b) * (x / b) ** c)


def partial_f_c(x, a, b, c):
    return -f_profile(x, a, b, c) * (x / b) ** c * np.log(x / b)


def partial_I_a(x, dx, a, b, c):
    return np.sum(partial_f_a(x, a, b, c) * x**2) * dx


def partial_I_b(x, dx, a, b, c):
    return np.sum(partial_f_b(x, a, b, c) * x**2) * dx


def partial_I_c(x, dx, a, b, c):
    return np.sum(partial_f_c(x, a, b, c) * x**2) * dx


def partial_N_a(x, I_total, I_i, dx, A, Nsat, a, b, c):
    return (
        4
        * np.pi
        * Nsat
        * A
        * (partial_I_a(x, dx, a, b, c) - (I_i / I_total) * partial_I_a(x, dx, a, b, c))
    )


def partial_N_b(x, I_total, I_i, dx, A, Nsat, a, b, c):
    return (
        4
        * np.pi
        * Nsat
        * A
        * (partial_I_b(x, dx, a, b, c) - (I_i / I_total) * partial_I_b(x, dx, a, b, c))
    )


def partial_N_c(x, I_total, I_i, dx, A, Nsat, a, b, c):
    return (
        4
        * np.pi
        * Nsat
        * A
        * (partial_I_c(x, dx, a, b, c) - (I_i / I_total) * partial_I_c(x, dx, a, b, c))
    )


partial_derivative_list = [partial_N_a, partial_N_b, partial_N_c]


class LUDecomposition:
    def __init__(self, a: np.ndarray):
        """This class performs LU decomposition, where a matrix A is decomposed in two matrices L and U.
        Here L is a Lower Triangular matrix (only elements on or below diagonal), and U is an Upper triangular matrix (only elements on or above the diagonal).
        We can use these to solve the equation A*x = (L*U)*x = L*(U*x) = b, by first solving L*y=b and then U*x=y.
        Use the constructor of the class to do the decomposition, using Crout's algorithm (slide 12 lecture 3)
        Then the instance of the object holds the LU decomposed matrix.
        We can then call the solve method as many times as we like, for as many b's as we like.
        """
        self.nrows, self.ncolumns = a.shape[0], a.shape[1]
        self.LU_matrix = np.identity(
            self.ncolumns
        )  # step 1: construct an identity matrix to start
        for j in range(self.ncolumns):
            self.LU_matrix[0, j] = a[0, j]  # for i = 0, beta_0j = a_0j
            for i in range(
                1, self.nrows
            ):  # starting from 0 or 1 should not make a difference, as the first row is already set to the correct values, but we can skip it to save some time
                if i <= j:
                    self.LU_matrix[i, j] = a[i, j] - sum(
                        self.LU_matrix[i, k] * self.LU_matrix[k, j] for k in range(i)
                    )  # beta_ij = a_ij - sum (alpha_ik beta_kj) from k=0 to i-1. range doesn't include end point!
                if i > j:
                    self.LU_matrix[i, j] = (
                        a[i, j]
                        - sum(
                            self.LU_matrix[i, k] * self.LU_matrix[k, j]
                            for k in range(j)
                        )
                    ) / self.LU_matrix[
                        j, j
                    ]  # alpha_ij = a_ij - sum (alpha_ik beta_kj) from k=0 to j-1. range doesn't include end point!

    def get_LU_decomposition(self):
        return self.LU_matrix

    def solve(self, b: np.ndarray) -> np.ndarray:
        # Forward substitution first: L*y=b
        b_size = len(b)
        y = np.zeros(b_size)
        x = np.zeros(b_size)
        y[0] = b[
            0
        ]  # don't need to divide by LU_matrix[i,i] as for the forward substitution, the diagonal elements of L are all 1's
        for i in range(1, b_size):
            y[i] = b[i] - sum(self.LU_matrix[i, j] * y[j] for j in range(i))

        # Now do the backsubstitution
        x[b_size - 1] = y[b_size - 1] / self.LU_matrix[b_size - 1, b_size - 1]
        for i in reversed(range(b_size)):
            x[i] = (
                y[i] - sum(self.LU_matrix[i, j] * x[j] for j in range(i + 1, b_size))
            ) / self.LU_matrix[i, i]
        return x


class LevenbergMarquardt:
    def __init__(
        self,
        x: np.ndarray,
        y: np.ndarray,
        partial_derivative_list: list[Callable],
        sigma,
        f: Callable,
        p: np.ndarray,
        linear,
        A,
        Nsat,
    ):
        """Implement the Levenberg Marquardt algorithm.
        x are the abscissa points of the measured data, y are the measured data values.
        partial_derivative_list should contain a list of the partial derivatives of the function to be fitted, with the partial derivative to each parameter.
        f is the function (model) to be fitted to the data, for which we try to find the best-fit parameters
        p is the initial estimation of the parameter vector.
        linear is a boolean to indicate if the model function to be fitted is linear in its parameters.
        If that's the case, Levenberg Marquardt will converge to the correct solution in 1 iteration, and we don't have to do a second one to confirm we are not longer improving.
        """
        self.x = x
        self.y_measured = y
        if len(self.x) != len(self.y_measured):
            raise ValueError("x and y should have same length")
        self.partial_derivative_list = partial_derivative_list
        self.sigma: Union[float, list, tuple, np.ndarray] = (
            sigma  # noqa: UP007 use old typing for compatibility with vdesk
        )
        if np.any(self.sigma == 0):  # works for ints, floats, 1D and 2D arrays
            raise ValueError("No value in sigma can be zero!")
        self.f = f
        self.p = p
        self.linear = linear
        self.A = A  # I adapted by algorithm for this use case
        self.Nsat = Nsat

    def _calculate_model(self):
        # calculate the expected (=model) y values by putting the x values together with the current parameter estimation into the function
        # self.y_model will now be a vector of length # of bins, with every x the (mean?) x value of that bin and every y the Ni_tilde, the mean number of satellites per halo in each radial bin according to the model.
        self.y_model = self.f(
            self.x, self.A, self.Nsat, *self.p
        )  # unpack the vector of parameters into the function

    def _construct_jacobian(self):
        """Construct the Jacobian, the matrix holding partial derivatives i.e. dau y_i/dau p_j for as set of datapoints and another set of parameters.
        So why do we supply an x array instead of a y array? because we fill in x in the analytical partial derivative of each parameter
        """
        self.J = np.zeros((len(self.x), len(self.partial_derivative_list)))
        I_total = np.sum(
            f_profile(xval, *self.p) * xval**2 for xval in self.x
        )  # Supply f(x,a,b,c) with a,b and c in self.p

        for i, x_value in enumerate(self.x):
            if (
                i != len(self.x) - 1
            ):  # Since we have n-1 intervals, don't recalculate dx for the last interval
                dx = (
                    self.x[i + 1] - self.x[i]
                )  # since x spacing can be logarithmic, recalculate dx
            I_i = f_profile(x_value, *self.p) * x_value**2
            for j, partial_derivative in enumerate(self.partial_derivative_list):
                self.J[i, j] = partial_derivative(
                    x_value, I_total, I_i, dx, self.A, self.Nsat, *self.p
                )  # unpack the vector of parameters in the partial derivative

    def _construct_inverse_covariance_matrix(self):
        # We had to adapt this method for this problem, where the variance and thus the covariance matrix is dependent on N_i_tilde, which is dependent on the parameters
        # We left only the case for Chi Squared, where the standard deviation can be different for each x_i, but there is no correlation between the sigmas for various x_i's)
        cov_inv = np.identity(len(self.y_model))
        self.std2_inv_list = 1 / self.y_model
        for i in range(len(cov_inv)):
            cov_inv[i, i] *= self.std2_inv_list[i]
        self.std2_inverse_matrix = cov_inv

    def _calculate_alpha(self):
        """Alpha is the square matrix with nrows = ncols = the number of parameters in the function that we are fitting.
        The nrows and ncols should be equal to the number of columns in the supplied Jacobian.
        std2_inverse_matrix is the inverse of the standard deviations squared of the elements.
        This forms the covariane matrix of the parameters.
        """
        # We need to calculate the sum of dau y_i/ dau p_k times dau y_i/dau p_l for the sum of i to N-1, for each combination of k and l.
        # Now for efficiency: we transpose the Jacobian which allows us to do matrix multiplication for each k,l combination
        # Row from k times i matrix times column i times l matrix
        self.alpha = self.J.T @ self.std2_inverse_matrix @ self.J
        self.alpha_accent = self.alpha + np.eye(self.alpha.shape[0]) * self.lmbda

    def _calculate_beta(self):
        # Beta is the residual: The measured y value minus the predicted model y value!
        self.beta = self.J.T @ self.std2_inverse_matrix @ self.y_delta.T

    def _solve_delta_p(self):
        """Solve the linear system alpha_accent delta_p = beta, for delta_p, using our own implementation of LU Decomposition!"""
        lu_decomposition_instance = LUDecomposition(self.alpha_accent)
        return lu_decomposition_instance.solve(self.beta)
        # np.linalg.solve(self.alpha_accent, self.beta) # Built in np.linalg.solve() if own LU Decomposition algorithm fails

    def _calculate_chisquare(self):
        """We calculate the chi squared every time we make a new estimation of our parameter vector p.
        The first will be a guess, the rest will follow from iteratively fitting our model to our data.
        The fit results from solving the linear system alpha delta_p = b for delta_p, where delta_p is the change in the parameter vector
        """
        if not isinstance(self.sigma, (list, tuple)):
            raise TypeError(
                "sigma should be a list or tuple of standard deviations for use in chi square"
            )
        return np.sum(
            self.y_delta**2 / self.y_model
        )  # I replaced * self.std2 here with / self.y_model, since we are told the model mean and variance are equal to N_i_tilde, which changes with the parameters a,b and c

    def _do_iteration(self):
        self._construct_jacobian()
        self._calculate_alpha()
        self._calculate_beta()
        delta_p = (
            self._solve_delta_p()
        )  # solve the linear system of equations to find the change in our parameter estimation
        self.p += delta_p  # add deltas for a, b and c
        self.A = get_normalization_constant(
            *self.p
        )  # recalculate A based on the new a, b and c
        self._calculate_model()
        self._construct_inverse_covariance_matrix()  # Since in this case the covariance matrix depends on the model, recalculate covariance matrix after updating model
        self.y_delta = (
            self.y_measured - self.y_model
        )  # used for both beta (the residual) and chisquare, only calculate once per model update
        self.new_chisquare = self._calculate_chisquare()

    def iteratively_improve_solution(
        self, weight: float = 10.0, improvement_threshold: float = 0.01
    ):
        self._calculate_model()  # Calculate the y model values for the initial parameter estimation p_0
        self._construct_inverse_covariance_matrix()  # Since in this case the covariance matrix depends on the model, recalculate covariance matrix after updating model
        self.y_delta = (
            self.y_measured - self.y_model
        )  # used for both beta (the residual) and chisquare, only calculate once per model update
        self.old_chisquare = (
            self._calculate_chisquare()
        )  # Step 1: calculate chisquare for p_0
        self.lmbda = 1e-6
        self._do_iteration()
        self.num_iterations = 1
        if (
            self.linear
        ):  # If model function is linear in parameters, Levenberg Marquardt will converge to the correct solution in 1 iteration, and we don't have to do a second one to confirm we are not longer improving.
            return self.p, self.num_iterations

        while (
            np.abs(self.new_chisquare - self.old_chisquare) > improvement_threshold
        ):  # while solution keeps improving, keep going
            if (
                self.new_chisquare > self.old_chisquare
            ):  # Old solution was better, keep old solution
                self.lmbda *= weight  # We are far from the minimum, make bigger steps (more steepest descent)
            else:  # New solution is better, update old solution to new solution
                self.old_chisquare = self.new_chisquare
                self.lmbda /= weight  # We are close to the minimum, make smaller steps (more Quasi Newton)
            self._do_iteration()
            self.num_iterations += 1
        return (
            self.p,
            self.num_iterations,
            self.old_chisquare,
        )  # self.p now contains the parameters for the best fit, the number of iterations, and the minimum chi square value
