#!/bin/bash

# If you get a permission denied error for run.sh itself, run this line in the terminal:
chmod +x ./run.sh

# If you get errors about weird (return) characters, and/or you edited run.sh on Windows, run this command:
dos2unix ./run.sh &>/dev/null

# Make sure you do NOT run in a virtual environment (e.g. conda, uv), or your results may be different than when we run your code
# On the STRW computers, you may need to run "module purge" if you load any modules at startup
pythonversion="$( python3 --version | cut -d' ' -f2 )"
if [ "${pythonversion}" != "3.9.25" ] ; then
    echo "WARNING: Python version is different from the default vdesk one (${pythonversion} vs 3.9.25), this may or may not cause differences/errors."
fi
matplotlibversion="$( python3 -m pip list | grep "matplotlib " | tr -s ' ' | cut -d' ' -f2 )"
if [ "${matplotlibversion}" != "3.9.0" ] ; then
    echo "WARNING: Matplotlib version is different from the default vdesk one (${matplotlibversion} vs 3.9.0), this may or may not cause differences/errors."
fi
numpyversion="$( python3 -m pip list | grep "numpy " | tr -s ' ' | cut -d' ' -f2 )"
if [ "${numpyversion}" != "1.26.4" ] ; then
    echo "WARNING: Numpy version is different from the default vdesk one (${numpyversion} vs 1.26.4), this may or may not cause differences/errors."
fi

# Check if black formatter is installed
if ! python3 -m black --version &>/dev/null ; then
    echo "Black formatter not found. Installing..."
    python3 -m pip install black
fi

# Format all python files (note that this assumes your python files are all in the same directory as run.sh)
echo "Uniformly formatting Python code..."
python3 -m black .

echo "Clearing/creating the plotting directory..."
if [ ! -d "Plots" ]; then
  mkdir Plots
fi
rm -rf Plots/*

echo "Clearing/creating the code directory..."
if [ ! -d "Code" ]; then
  mkdir Code
fi
rm -rf Code/*

echo "Downloading Vandermonde.txt..."
wget -q -O Vandermonde.txt "https://home.strw.leidenuniv.nl/~daalen/Handin_files/Vandermonde.txt"

echo "Running Python script to solve the Poisson distribution in 1a..."
python3 Q1_solution.py

# Copy the code to a text file which will be shown in the PDF
cat Q1_solution.py > Code/Poisson_code.txt

echo "Running the Python script to solve the Vandermonde question 2..."
python3 Q2_solution.py

# Copy the code to a text file which will be shown in the PDF
cat Q2_solution.py > Code/Vandermonde_all_code.txt

echo "Compiling LaTeX..."
pdflatex -interaction=batchmode NURA_handin_1.tex
pdflatex -interaction=batchmode NURA_handin_1.tex &>/dev/null # Run a second time to fix links/references

echo "run.sh completed! Don't forget to hand in a *clean* version of this directory (remove downloaded data, the Plots and Code directories)."
